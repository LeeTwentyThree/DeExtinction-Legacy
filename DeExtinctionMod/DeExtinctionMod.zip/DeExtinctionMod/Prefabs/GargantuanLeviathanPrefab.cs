﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMLHelper.V2.Assets;
using SMLHelper.V2.Crafting;
using SMLHelper.V2.Utility;
using UnityEngine;
using DeExtinctionMod.Mono;
using System.Reflection;

namespace DeExtinctionMod.Prefabs
{
    public class GargantuanLeviathanPrefab : Spawnable
    {
        static GameObject prefab;

        public GargantuanLeviathanPrefab(string classId, string friendlyName, string description) : base(classId, friendlyName, description)
        {

        }



        public override GameObject GetGameObject()
        {
            if (prefab == null)
            {
                GameObject reaper = CraftData.GetPrefabForTechType(TechType.ReaperLeviathan);
                ReaperLeviathan reaperComponent = reaper.GetComponent<ReaperLeviathan>();
                TrailManager reaperTrail = reaper.GetComponentInChildren<TrailManager>();

                prefab = QPatch.assetBundle.LoadAsset<GameObject>("GargantuanPrefab");

                Helpers.AddNecessaryCreatureComponents(this, prefab, LargeWorldEntity.CellLevel.VeryFar, EcoTargetType.Leviathan, VFXSurfaceTypes.organic);
                Helpers.ApplySNShaders(prefab);
                BehaviourLOD bLod = Helpers.EssentialComponent_BehaviourLOD(prefab, 200f, 400f, 1000f);

                LastScarePosition lastScare = prefab.AddComponent<LastScarePosition>();

                LiveMixin liveMixin = prefab.AddComponent<LiveMixin>();
                liveMixin.data = Helpers.CreateNewLiveMixinData();
                liveMixin.data.knifeable = true;
                liveMixin.data.maxHealth = float.MaxValue;
                liveMixin.data.canResurrect = true;

                GargantuanLeviathan leviathan = prefab.AddComponent<GargantuanLeviathan>();
                reaperComponent.CopyFields<Creature>(leviathan);
                leviathan.liveMixin = liveMixin;
                Helpers.SetPrivateField(typeof(Creature), leviathan, "traitsAnimator", leviathan.GetComponentInChildren<Animator>());

                CreatureRoar roar = prefab.AddComponent<CreatureRoar>();
                roar.minRoarDistance = 20f;
                roar.maxRoarDistance = 400f;
                roar.animationName = "roar";
                roar.clipPrefix = "EchoRoar";

                LastTargetUpdated lastTarget = prefab.AddComponent<LastTargetUpdated>();
                lastTarget.roar = roar;

                Rigidbody rb = Helpers.EssentialComponent_Rigidbody(prefab, 100000f);

                WorldForces worldForces = Helpers.EssentialComponent_WorldForces(prefab, rb);

                DealDamageOnImpact dealDamageOnImpact = prefab.AddComponent<DealDamageOnImpact>();
                dealDamageOnImpact.speedMinimumForDamage = 3f;
                dealDamageOnImpact.mirroredSelfDamage = false;

                SwimBehaviour swim = Helpers.EssentialComponentSystem_Swimming(prefab, 0.25f, rb);

                AggressiveToPilotingVehicle atpv = prefab.AddComponent<AggressiveToPilotingVehicle>();
                atpv.aggressionPerSecond = 1f;
                atpv.range = 100f;
                atpv.creature = leviathan;
                atpv.lastTarget = lastTarget;

                TrailManagerUpdated trail = prefab.SearchChild("Bone").AddComponent<TrailManagerUpdated>(); //This doesn't work, yet.
                trail.trails = trail.transform.GetChild(0).GetComponentsInChildren<Transform>();
                trail.rootTransform = prefab.transform;
                trail.rootSegment = trail.transform;
                trail.levelOfDetail = bLod;
                trail.segmentSnapSpeed = reaperTrail.segmentSnapSpeed;
                trail.maxSegmentOffset = reaperTrail.maxSegmentOffset;
                trail.allowDisableOnScreen = false;
                AnimationCurve decreasing = new AnimationCurve(new Keyframe[] { new Keyframe(0f, 0.25f), new Keyframe(1f, 0.75f) });
                trail.pitchMultiplier = decreasing;
                trail.rollMultiplier = decreasing;
                trail.yawMultiplier = decreasing;

                GameObject mouth = prefab.SearchChild("Mouth");
                OnTouch onTouch = mouth.AddComponent<OnTouch>();
                onTouch.gameObject.AddComponent<Rigidbody>().isKinematic = true;

                MeleeAttackUpdated meleeAttack = prefab.AddComponent<MeleeAttackUpdated>();
                meleeAttack.mouth = mouth;
                meleeAttack.creature = leviathan;
                meleeAttack.liveMixin = liveMixin;
                meleeAttack.animator = leviathan.GetAnimator();
                meleeAttack.biteInterval = 2.5f;
                meleeAttack.lastTarget = lastTarget;
                meleeAttack.biteDamage = 100f;
                meleeAttack.eatHappyIncrement = 0f;
                meleeAttack.eatHungerDecrement = 0.4f;
                meleeAttack.biteAggressionThreshold = 0f;
                meleeAttack.biteAggressionDecrement = 0.2f;
                meleeAttack.onTouch = onTouch;

                #region CreatureActions

                SwimRandom actionSR = prefab.AddComponent<SwimRandom>();
                actionSR.swimRadius = new Vector3(100f, 5f, 100f);
                actionSR.swimVelocity = 30f;
                actionSR.swimInterval = 4f;
                actionSR.evaluatePriority = 0.5f;
                actionSR.priorityMultiplier = Helpers.Curve_Flat();

                AttackCyclops actionAtkCyclops = prefab.AddComponent<AttackCyclops>();
                actionAtkCyclops.swimVelocity = 25f;
                actionAtkCyclops.aggressiveToNoise = new CreatureTrait(0f, 0.1f);
                actionAtkCyclops.evaluatePriority = 0.9f;
                actionAtkCyclops.priorityMultiplier = Helpers.Curve_Flat();

                AttackLastTarget actionAtkLastTarget = prefab.AddComponent<AttackLastTarget>();
                actionAtkLastTarget.evaluatePriority = 0.95f;
                actionAtkLastTarget.swimVelocity = 80f;
                actionAtkLastTarget.aggressionThreshold = 0.02f;
                actionAtkLastTarget.minAttackDuration = 30f;
                actionAtkLastTarget.maxAttackDuration = 40f;
                actionAtkLastTarget.pauseInterval = 20f;
                actionAtkLastTarget.rememberTargetTime = 100f;
                actionAtkLastTarget.priorityMultiplier = Helpers.Curve_Flat();
                actionAtkLastTarget.lastTarget = lastTarget;

                PassBelowPlayerAction actionPassBelowPlayer = prefab.AddComponent<PassBelowPlayerAction>();

                Helpers.MakeAggressiveTo(prefab, 300f, EcoTargetType.Shark, 0f, 4f);
                Helpers.MakeAggressiveTo(prefab, 250f, EcoTargetType.Leviathan, 0f, 1f);
                Helpers.MakeAggressiveTo(prefab, 50f, EcoTargetType.SubDecoy, 0f, 1f);
                Helpers.MakeAggressiveTo(prefab, 50f, EcoTargetType.Whale, 0.1f, 1f);
                leviathan.eyeFOV = -1f;

                DiveAction actionDive = prefab.AddComponent<DiveAction>();

                RoarRandomAction actionRoar = prefab.AddComponent<RoarRandomAction>();

                #endregion

                List<CreatureAction> actionsList = new List<CreatureAction>() { actionSR, actionDive, actionAtkCyclops, actionAtkLastTarget, actionRoar, actionPassBelowPlayer };
                PropertyInfo prop = typeof(Creature).GetProperty("actions", BindingFlags.Default);
                if (null != prop && prop.CanWrite)
                {
                    prop.SetValue(leviathan, actionsList, null);
                }

            }
            return prefab;
        }
    }
}
