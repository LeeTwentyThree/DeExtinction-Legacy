﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QModManager.API.ModLoading;
using UnityEngine;
using System.IO;
using System.Reflection;
using DeExtinctionMod.Prefabs;
using DeExtinctionMod.Mono;
using SMLHelper.V2.Handlers;

namespace DeExtinctionMod
{
    [QModCore]
    public static class QPatch
    {
        public static AssetBundle assetBundle;

        public static GargantuanLeviathanPrefab leviathanPrefab;

        public static ModAudio modAudio;

        public static string ModFolderPath
        {
            get
            {
                return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            }
        }
        public static string AssetsPath
        {
            get
            {
                return Path.Combine(ModFolderPath, "Assets");
            }
        }
        public static string AssetBundlePath
        {
            get
            {
                return Path.Combine(AssetsPath, "deextinctionassets");
            }
        }

        [QModPatch]
        public static void Patch()
        {
            LoadAssetBundle();
            leviathanPrefab = new GargantuanLeviathanPrefab("gargantuan", "Gargantuan Leviathan", "An ancient creature thought to be extinct");
            leviathanPrefab.Patch();
            modAudio = new ModAudio();
            modAudio.Init();
            PDAHandler.AddCustomScannerEntry(leviathanPrefab.TechType, TechType.None, false, "Gargantuan", 0, 0, false);
            PDAEncyclopedia.EntryData gargantuanEntryData = new PDAEncyclopedia.EntryData()
            {
                key = "Gargantuan",
                path = "Leviathans/Gargantuan",
                nodes = new string[] { "Leviathans" },
                unlocked = false
            };
            PDAEncyclopediaHandler.AddCustomEntry(gargantuanEntryData);
            LanguageHandler.SetLanguageLine("Ency_Gargantuan", "Gargantuan Leviathan");
            LanguageHandler.SetLanguageLine("EncyDesc_Gargantuan", "Thought to be extinct, this ancient leviathan appears to have recently migrated to this location from another ecosystem on this planet. Already seeming biologically impossible, this appears to be a juvenile specimen.\n\nAppearance:\nThe Gargantuan leviathan ");


        }

        static void LoadAssetBundle()
        {
            assetBundle = AssetBundle.LoadFromFile(AssetBundlePath);
        }
    }
}
