﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace DeExtinctionMod.Mono
{
    public class DiveAction : CreatureAction
    {
        public override float Evaluate(Creature creature)
        {
            if(creature.transform.position.y > Ocean.main.GetOceanLevel() - 90f)
            {
                return 0.75f;
            }
            return 0f;
        }

        public override void StartPerform(Creature creature)
        {
            swimBehaviour.SwimTo(transform.position + new Vector3(0f, -100f, 0f), 25f);
        }
    }
}
