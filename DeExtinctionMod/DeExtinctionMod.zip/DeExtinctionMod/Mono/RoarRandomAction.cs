﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace DeExtinctionMod.Mono
{
    public class RoarRandomAction : CreatureAction
    {
        public float roarIntervalMin = 4f;
        public float roarIntervalMax = 8f;
        float timeNextRoar;
        CreatureRoar roarAction;

        void Start()
        {
            timeNextRoar = Time.time + Random.Range(roarIntervalMin, roarIntervalMax);
            roarAction = GetComponent<CreatureRoar>();
        }
        public override float Evaluate(Creature creature)
        {
            if(Time.time > timeNextRoar)
            {
                return 0.5f;
            }
            return 0f;
        }
        public override void StartPerform(Creature creature)
        {
            if(roarAction == null) roarAction = GetComponent<CreatureRoar>();
            timeNextRoar = Time.time + Random.Range(roarIntervalMin, roarIntervalMax);
            roarAction.PlayRoar();
        }
    }
}
