﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace DeExtinctionMod.Mono
{
    public class MeleeAttackUpdated : MeleeAttack
    {
        public OnTouch onTouch;

        void Start()
        {
            onTouch.onTouch = new OnTouch.OnTouchEvent();
            onTouch.onTouch.AddListener(OnTouch);
        }
        public override void OnTouch(Collider collider)
        {
            base.OnTouch(collider);
        }

        public override bool CanBite(GameObject target)
        {
            if (Time.time < timeLastBite + biteInterval)
            {
                return false;
            }
            return true;
        }
    }
}
